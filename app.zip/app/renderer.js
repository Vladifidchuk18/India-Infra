const { ipcRenderer } = require('electron');

const overlay = document.querySelector('#overlay');
const holder = document.querySelector('#holder');
const webview = document.querySelector('#webview');
const btnClose = document.querySelector('#btnClose');
const btnFullscreen = document.querySelector('#btnFullscreen');
const btnExitFullscreen = document.querySelector('#btnExitFullscreen');
const btnReduceWindow = document.querySelector('#btnReduceWindow');
const btnEnlargeWindow = document.querySelector('#btnEnlargeWindow');
const appTitle = document.querySelector('#appTitle');
const appTitleHead = document.querySelector('#appTitleHead');

let appTitleStr = "מאוחדת", appTitleShort = "מאוחדת";

overlay.style.display = 'none';
btnClose.style.display = 'inline-block';
btnFullscreen.style.display = 'inline-block';
btnExitFullscreen.style.display = 'none';
btnReduceWindow.style.display = 'inline-block';
btnEnlargeWindow.style.display = 'none';

btnClose.addEventListener('click', () => {
    ipcRenderer.send('closeApp');
});

btnFullscreen.addEventListener('click', () => {
    ipcRenderer.send('clickFullscreen');
    overlay.style.display = 'none';
    btnClose.style.display = 'inline-block';
    btnFullscreen.style.display = 'none';
    btnExitFullscreen.style.display = 'inline-block';
    btnReduceWindow.style.display = 'none';
    btnEnlargeWindow.style.display = 'none';
    appTitle.innerText = appTitleStr;
    appTitleHead.innerText = appTitleStr;
});

btnExitFullscreen.addEventListener('click', () => {
    ipcRenderer.send('clickExitFullscreen');
    overlay.style.display = 'none';
    btnClose.style.display = 'inline-block';
    btnFullscreen.style.display = 'inline-block';
    btnExitFullscreen.style.display = 'none';
    btnReduceWindow.style.display = 'inline-block';
    btnEnlargeWindow.style.display = 'none';
    appTitle.innerText = appTitleStr;
    appTitleHead.innerText = appTitleStr;
});

btnReduceWindow.addEventListener('click', () => {
    ipcRenderer.send('clickSecondary');
    overlay.style.display = 'block';
    btnClose.style.display = 'none';
    btnFullscreen.style.display = 'none';
    btnExitFullscreen.style.display = 'none';
    btnReduceWindow.style.display = 'none';
    btnEnlargeWindow.style.display = 'inline-block';
    appTitle.innerText = appTitleShort;
    appTitleHead.innerText = appTitleShort;
});

btnEnlargeWindow.addEventListener('click', () => {
    ipcRenderer.send('clickPrimary');
    overlay.style.display = 'none';
    btnClose.style.display = 'inline-block';
    btnFullscreen.style.display = 'inline-block';
    btnExitFullscreen.style.display = 'none';
    btnReduceWindow.style.display = 'inline-block';
    btnEnlargeWindow.style.display = 'none';
    appTitle.innerText = appTitleStr;
    appTitleHead.innerText = appTitleStr;
});

overlay.addEventListener('click', () => {
    ipcRenderer.send('clickPrimary');
    overlay.style.display = 'none';
    btnClose.style.display = 'inline-block';
    btnFullscreen.style.display = 'inline-block';
    btnExitFullscreen.style.display = 'none';
    btnReduceWindow.style.display = 'inline-block';
    btnEnlargeWindow.style.display = 'none';
    appTitle.innerText = appTitleStr;
    appTitleHead.innerText = appTitleStr;
});

ipcRenderer.on('maximize', (event, arg) => {
    btnFullscreen.click();
});

ipcRenderer.on('unmaximize', (event, arg) => {
    btnExitFullscreen.click();
});

// Event handlers for loading events.
// Use these to handle loading screens, transitions, etc
onload = () => {
    if (process.env.npm_config_appTitle) {
        appTitle.innerText = process.env.npm_config_appTitle;
        appTitleHead.innerText = process.env.npm_config_appTitle;
        appTitleStr = process.env.npm_config_appTitle;
        appTitleShort = process.env.npm_config_appTitle.substr(0,4) + "...";
    }

    const loadstart = () => {
        webview.style.visibility = 'hidden';
        resizeWebView();
    }

    const loadstop = () => {
        holder.style.backgroundImage  =  "url('')";
        webview.style.visibility = 'visible';
        resizeWebView();
    }

    webview.addEventListener('did-start-loading', loadstart);
    webview.addEventListener('did-stop-loading', loadstop);

    if (process.env.npm_config_siteUrl) {
        webview.style.visibility = 'visible';
        webview.src = process.env.npm_config_siteUrl;
    }
    else {
        holder.style.backgroundImage  = "url('')";
        webview.style.visibility = 'hidden';
    }
}

function resizeWebView() {
    var buffer = 0; //scroll bar buffer
    var height = document.documentElement.clientHeight;
    height -= pageY(webview)+ buffer;
    height = (height < 0) ? 0 : height;
    webview.style.height = height + 'px';
}

function pageY(elem) {
    return elem.offsetParent ? (elem.offsetTop + pageY(elem.offsetParent)) : elem.offsetTop;
}

window.onresize = resizeWebView;